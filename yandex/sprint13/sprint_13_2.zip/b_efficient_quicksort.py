# contest ID 88396997
def quick_sort(array, low, high):
    def partition(array, low, high):
        pivot = array[high]
        smaller_index = low - 1
        for current_index in range(low, high):
            if not __compare(array[current_index], pivot):
                smaller_index += 1
                swap(array, smaller_index, current_index)
        swap(array, smaller_index + 1, high)
        return smaller_index + 1

    def __compare(participant1, participant2):
        if participant1[1] > participant2[1]:
            return False
        if participant1[1] < participant2[1]:
            return True
        if participant1[2] < participant2[2]:
            return False
        if participant1[2] > participant2[2]:
            return True
        return False if participant1[0] < participant2[0] else True

    def swap(array, smaller_index, current_index):
        array[smaller_index], array[current_index] = (
            array[current_index],
            array[smaller_index],
        )

    if low < high:
        pivot_index = partition(array, low, high)
        quick_sort(array, low, pivot_index - 1)
        quick_sort(array, pivot_index + 1, high)
    return array


if __name__ == "__main__":
    count_participants = int(input())
    participants = [input().split() for _ in range(count_participants)]
    sorted_participants = quick_sort(
        [
            (login, int(solved_tasks), int(penalty))
            for login, solved_tasks, penalty in participants
        ],
        0,
        count_participants - 1,
    )
    print(
        *[participant for participant, _, _ in sorted_participants], sep='\n'
    )
