# contest ID 88341501
def quick_sort(arr, low, high):
    while low < high:
        pivot_index = partition(arr, low, high)
        if pivot_index - low < high - pivot_index:
            quick_sort(arr, low, pivot_index - 1)
            low = pivot_index + 1
        else:
            quick_sort(arr, pivot_index + 1, high)
            high = pivot_index - 1


def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1
    for j in range(low, high):
        if compare(arr[j], pivot) <= 0:
            i += 1
            swap(arr, i, j)
    swap(arr, i + 1, high)
    return i + 1


def compare(participant1, participant2):
    if participant1[1] > participant2[1]:
        return -1
    elif participant1[1] < participant2[1]:
        return 1
    else:
        if participant1[2] < participant2[2]:
            return -1
        elif participant1[2] > participant2[2]:
            return 1
        else:
            return -1 if participant1[0] < participant2[0] else 1


def swap(arr, i, j):
    arr[i], arr[j] = arr[j], arr[i]


if __name__ == "__main__":
    count_participants = int(input())
    participants = []
    for _ in range(count_participants):
        login, solved_tasks, penalty = input().split()
        participants.append((login, int(solved_tasks), int(penalty)))
    quick_sort(participants, 0, count_participants - 1)
    for participant in participants:
        print(participant[0])
