# contest ID 87667410
from typing import List


def calculate_distances(n: int, street: List[int]) -> List[int]:
    distances = [0] * n
    prev_zero = -float('inf')
    for i in range(n):
        if street[i] == 0:
            prev_zero = i
        distances[i] = i - prev_zero
    prev_zero = float('inf')
    for i in range(n - 1, -1, -1):
        if street[i] == 0:
            prev_zero = i
        distances[i] = min(distances[i], prev_zero - i)
    return distances


n = int(input())
street = list(map(int, input().split()))
distances = calculate_distances(n, street)
print(*distances)
