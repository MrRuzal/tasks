# contest ID 87669461
from typing import List
import collections


def calculate_score(k: int, buttons: List[List[str]]) -> int:
    count = collections.Counter(
        c for row in buttons for c in row if c.isdigit()
    )
    score = sum(1 for key, v in count.items() if v <= k)
    return score


k = int(input()) * 2
buttons = [list(input().strip()) for _ in range(4)]
print(calculate_score(k, buttons))
