# contest ID 87696553
from typing import List
import collections


def calculate_score(one_player_buttons: int, buttons: List[List[str]]) -> int:
    count = collections.Counter(c for row in buttons for c in row)
    return sum(
        v <= one_player_buttons * 2 for c, v in count.items() if c.isdigit()
    )


if __name__ == '__main__':
    one_player_buttons = int(input())
    buttons = f'{input()}{input()}{input()}{input()}'
    print(calculate_score(one_player_buttons, buttons))
