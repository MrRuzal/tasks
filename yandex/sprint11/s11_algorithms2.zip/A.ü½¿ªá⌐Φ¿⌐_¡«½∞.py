# contest ID 87696327
from typing import List


def calculate_distances(street: List[int]) -> List[int]:
    zeros = [i for i in range(len(street)) if street[i] == '0']
    distances = [0] * len(street)
    for i in range(0, zeros[0]):
        distances[i] = zeros[0] - i
    for j in range(0, len(zeros) - 1):
        for i in range(zeros[j] + 1, zeros[j + 1]):
            distances[i] = min(i - zeros[j], zeros[j + 1] - i)
    for i in range(zeros[-1] + 1, len(street)):
        distances[i] = i - zeros[-1]
    return distances


if __name__ == '__main__':
    input()
    print(*calculate_distances(input().split()))
