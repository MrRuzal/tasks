# contest ID 87696327
from typing import List


def calculate_distances(
    street: List[str], target_value: str = '0'
) -> List[int]:
    zeros = [
        index for index, value in enumerate(street) if value == target_value
    ]
    distances = [0] * len(street)
    first_zero = zeros[0]

    for index in range(0, first_zero):
        distances[index] = first_zero - index

    for zero_index in range(0, len(zeros) - 1):
        left_zero = zeros[zero_index]
        right_zero = zeros[zero_index + 1]
        for index in range(left_zero + 1, right_zero):
            distances[index] = min(index - left_zero, right_zero - index)

    last_zero = zeros[-1]
    for index in range(last_zero + 1, len(street)):
        distances[index] = index - last_zero
    return distances


if __name__ == '__main__':
    input()
    print(*calculate_distances(input().split()))
