# contest ID 87706597
import collections


def calculate_score(
    one_player_buttons: int, buttons: str, players_count: int = 2
) -> int:
    return sum(
        count <= one_player_buttons * players_count
        for value, count in collections.Counter(buttons).items()
        if value != '.'
    )


if __name__ == '__main__':
    print(
        calculate_score(
            one_player_buttons=int(input()),
            buttons=input() + input() + input() + input(),
        )
    )
