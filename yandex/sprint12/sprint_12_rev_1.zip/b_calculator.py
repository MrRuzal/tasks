# contest ID 87968779
def calculate(expression):
    stack = []
    items = expression.split()

    for item in items:
        if item.lstrip('-').isdigit():
            stack.append(int(item))
        else:
            operand2 = stack.pop()
            operand1 = stack.pop()
            if item == '+':
                result = operand1 + operand2
            elif item == '-':
                result = operand1 - operand2
            elif item == '*':
                result = operand1 * operand2
            elif item == '/':
                result = operand1 // operand2
            stack.append(result)
    return stack[-1]


if __name__ == '__main__':
    print(calculate(input()))
