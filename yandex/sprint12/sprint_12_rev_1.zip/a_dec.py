# contest ID 87969441
class Dec:
    def __init__(self, size):
        self.size = size
        self.buffer = [None] * size
        self.front = 0
        self.back = 0
        self.count = 0

    def push_back(self, value):
        if self.count == self.size:
            print("error")
            return
        self.buffer[self.back] = value
        self.back = (self.back + 1) % self.size
        self.count += 1

    def push_front(self, value):
        if self.count == self.size:
            print("error")
            return
        self.front = (self.front - 1) % self.size
        self.buffer[self.front] = value
        self.count += 1

    def pop_front(self):
        if self.count == 0:
            print("error")
            return
        value = self.buffer[self.front]
        self.front = (self.front + 1) % self.size
        self.count -= 1
        print(value)

    def pop_back(self):
        if self.count == 0:
            print("error")
            return
        self.back = (self.back - 1) % self.size
        value = self.buffer[self.back]
        self.count -= 1
        print(value)


if __name__ == "__main__":
    n = int(input())
    dec = Dec(int(input()))

    for _ in range(n):
        command = input().split()
        if command[0] == "push_back":
            dec.push_back(int(command[1]))
        elif command[0] == "push_front":
            dec.push_front(int(command[1]))
        elif command[0] == "pop_front":
            dec.pop_front()
        elif command[0] == "pop_back":
            dec.pop_back()
