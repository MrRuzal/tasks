# contest ID 87987399
class Deque:
    def __init__(self, size):
        self.size = size
        self.buffer = [None] * size
        self.front = 0
        self.back = 0
        self.count = 0

    def push_back(self, value):
        if self.count == self.size:
            raise Exception('Очередь переполнена')
        self.buffer[self.back] = value
        self.back = (self.back + 1) % self.size
        self.count += 1

    def push_front(self, value):
        if self.count == self.size:
            raise Exception('Очередь переполнена')
        self.front = (self.front - 1) % self.size
        self.buffer[self.front] = value
        self.count += 1

    def pop_front(self):
        if self.count == 0:
            raise Exception('Очередь пуста')
        value = self.buffer[self.front]
        self.front = (self.front + 1) % self.size
        self.count -= 1
        return value

    def pop_back(self):
        if self.count == 0:
            raise Exception('Очередь пуста')
        self.back = (self.back - 1) % self.size
        value = self.buffer[self.back]
        self.count -= 1
        return value


if __name__ == "__main__":
    number_teams = int(input())
    deque = Deque(int(input()))

    for _ in range(number_teams):
        command, *params = input().split()
        try:
            method = getattr(deque, command)
            result = method(*params)
            if result is not None:
                print(result)
        except AttributeError:
            raise ValueError("Неверная команда")
        except Exception:
            print("error")
