# contest ID 87986839
class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if self.is_empty():
            raise IndexError("Стек пуст")
        return self.items.pop()

    def is_empty(self):
        return len(self.items) == 0


def calculate(expression, converter=int):
    stack = Stack()
    items = expression.split()

    for item in items:
        try:
            value = converter(item)
            stack.push(value)
        except ValueError:
            operand2 = stack.pop()
            operand1 = stack.pop()
            result = operation(item, operand1, operand2)
            stack.push(result)

    return stack.pop()


def operation(operator, operand1, operand2):
    operations = {
        '+': lambda x, y: x + y,
        '-': lambda x, y: x - y,
        '*': lambda x, y: x * y,
        '/': lambda x, y: x // y,
    }
    if operator in operations:
        return operations[operator](operand1, operand2)
    else:
        raise ValueError("Недопустимый оператор")


if __name__ == '__main__':
    print(calculate(input()))
