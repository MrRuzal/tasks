# contest ID 87992233
OPERATIONS = {
    '+': lambda x, y: x + y,
    '-': lambda x, y: x - y,
    '*': lambda x, y: x * y,
    '/': lambda x, y: x // y,
}


class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        try:
            return self.items.pop()
        except IndexError:
            raise IndexError("Стек пуст")


def calculate(items, converter=int, stack=Stack()):
    for item in items:
        try:
            stack.push(converter(item))
        except ValueError:
            operator = item
            operand2 = stack.pop()
            operand1 = stack.pop()
            if operator in OPERATIONS:
                result = OPERATIONS[operator](operand1, operand2)
                stack.push(result)
            else:
                raise ValueError(f"Недопустимый оператор: {operator}")
    return stack.pop()


if __name__ == '__main__':
    print(calculate(input().split()))
